"""Verify and restore the nested historical base and current overlay."""
from pathlib import Path
import hashlib,json,sys,zipfile
root=Path(__file__).resolve().parent
dest=Path(sys.argv[1] if len(sys.argv)>1 else 'restored').resolve()
if dest.exists():raise SystemExit('Choose a new output directory')
manifest=json.loads((root/'MANIFEST.json').read_bytes())
for name,digest in manifest['files'].items():
    p=(root/name).resolve()
    if not p.is_relative_to(root) or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError(name)
with zipfile.ZipFile(root/'version9-base.zip') as z:
    base=json.loads(z.read('MANIFEST.json'))
    for name,digest in base['files'].items():
        p=(dest/name).resolve();raw=z.read(name)
        if not p.is_relative_to(dest) or hashlib.sha256(raw).hexdigest()!=digest:raise ValueError(name)
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
for name in manifest['files']:
    if not name.startswith('current/'):continue
    relative=name[len('current/'):];p=(dest/relative).resolve()
    if not p.is_relative_to(dest):raise ValueError(name)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
print('Verified and restored Version 10. Run its check.py and check_valuation.py from the restored directory.')
