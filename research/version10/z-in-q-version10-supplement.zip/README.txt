Version 10 Issue 2 research supplement.
Run: python -B restore.py restored
Then read restored/research/version10/README.md.
No conversational transcript. Earlier full research history remains in the Version 7 handoff.
